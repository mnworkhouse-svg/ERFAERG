# Architecture (Phase 1)

## Decisions
| Layer | Choice | Why |
|---|---|---|
| Frontend (Part 2) | React + Vite + TypeScript + Tailwind, one SPA: `/` customer, `/admin/*` admin | A Mini App is client-only (no SEO/SSR), auth is a header; Next.js adds server complexity with no benefit. Deploys to Vercel / Cloudflare Pages. |
| Backend | Node 20 + Express 5 + TypeScript + Zod | Full control over transactions, webhook, file handling. |
| Database | PostgreSQL + Prisma | `SELECT ... FOR UPDATE SKIP LOCKED` for race-free stock allocation; Decimal money; strong constraints. |
| Bot | Bot API via **webhook** (secret token) | Works on Render/Railway/serverless; no polling process. |
| XLSX (Part 2) | `exceljs` + `multer` | Read + write, no known critical CVEs unlike old `xlsx` npm builds. |

## Flow
```
Telegram user -> Bot (/start) -> [অ্যাপ খুলুন web_app button] -> Mini App (React SPA)
Mini App --Authorization: tma <initData>--> Express API --> PostgreSQL
Admin (same Mini App, /admin) --same header--> API -> Admin table lookup -> RBAC -> PostgreSQL
API --Bot API--> user (notifications, XLSX delivery)
```

## Auth
- Every request carries `Authorization: tma <initData>`. Server verifies HMAC (`WebAppData` + bot token) and `auth_date` age. No JWT, no client-supplied telegram_id.
- Customer: user row upserted from verified data; BLOCKED users get 403.
- Admin: authority comes **only** from the `Admin` table (status ACTIVE). `SUPER_ADMIN_TELEGRAM_ID` bootstraps the first SUPER_ADMIN on first panel open.
- Permissions: `requireAdmin('PERMISSION')` on every admin route. `MANAGE_ADMINS` and `SYSTEM_SETTINGS` are stripped from non-super admins in code, even if stored in the DB.

## Money & stock safety
- Balances change only through `applyWalletTx` (row lock -> update -> ledger row, signed amount, sign checked against type).
- Deposit review locks the deposit row and requires `PENDING` (idempotent) + unique ledger key `(type, referenceType, referenceId)` as a second guard.
- Purchase: lock wallet -> validate -> `FOR UPDATE SKIP LOCKED` stock -> order/items -> mark SOLD -> debit. One transaction. `OrderItem.stockItemId` is UNIQUE: a stock row can never be sold twice.
- Price is always computed server-side.

## Stock model (generic)
`Product -> ProductField[]` (configurable columns) and `StockItem.data` JSON keyed by field keys. `fingerprint = sha256(canonical JSON)` + `UNIQUE(productId, fingerprint)` blocks duplicates. `StockImport` keeps history (total / imported / duplicates / invalid + row errors).

## API (Part 1 implemented)
| Method | Path | Auth |
|---|---|---|
| GET | /health | - |
| POST | /telegram/webhook | secret header |
| GET | /api/me | user |
| GET | /api/products | user |
| POST | /api/orders `{productId, quantity}` | user |
| GET | /api/orders | user |
| GET | /api/admin/me | any active admin |
| GET | /api/admin/deposits?status= | VIEW_DEPOSITS |
| POST | /api/admin/deposits/:id/approve | APPROVE_DEPOSITS |
| POST | /api/admin/deposits/:id/reject `{reason}` | REJECT_DEPOSITS |

Planned: deposits (user create + proof upload), payment methods, products/stock/XLSX import, users, admin management, audit log, dashboard, help/settings, order XLSX delivery.

## Folder structure
```
tg-shop/
  backend/  prisma/schema.prisma  src/{config,lib,middleware,services,routes,scripts}
  frontend/ (Part 2+)  src/{pages,components,api,i18n}
  docs/
```

## Deployment
Backend on Render/Railway (Node 20, Postgres add-on). Build: `npm run build`. Release: `npm run db:deploy`. Then once: `npm run set-webhook`. Frontend on Vercel/Cloudflare Pages; set its URL in `TELEGRAM_MINI_APP_URL` and `CORS_ORIGIN`. In @BotFather set the Mini App / menu button to the same URL.

## DB safeguards to add right after the first migration
```sql
-- npx prisma migrate dev --create-only --name safeguards   (then paste into the generated .sql)
ALTER TABLE "User" ADD CONSTRAINT user_balance_non_negative CHECK (balance >= 0);
ALTER TABLE "Product" ADD CONSTRAINT product_qty_valid CHECK ("minQty" >= 1 AND "maxQty" >= "minQty");
ALTER TABLE "PaymentMethod" ADD CONSTRAINT pm_amount_valid CHECK ("minAmount" > 0 AND "maxAmount" >= "minAmount");
```

## Run (Part 1)
```
cd backend && cp .env.example .env   # fill values
npm install
npx prisma migrate dev --name init
npm run dev
npm run set-webhook                  # needs PUBLIC_API_URL reachable over HTTPS
```
